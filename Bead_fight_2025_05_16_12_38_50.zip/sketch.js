function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}// Guerra na Roça: Caipiras contra a Invasão Alienígena
// Um jogo feito com p5.js

let larguraCanvas = 800;
let alturaCanvas = 600;

let jogador;
let defesas = [];
let alienigenas = [];
let recursos = 100;
let ondaAtual = 1;
let vidaPlantações = 100;
let vidaAnimais = 100;
let gameOver = false;
let projeteisJogador = []; // Array para os projéteis do jogador

let imgJogador;
let imgTratorMetralhadora;
let imgAlienBasico;

function preload() {
  // Carregue as imagens aqui
  // imgJogador = loadImage('assets/caipira.png');
  // imgTratorMetralhadora = loadImage('assets/trator_metralhadora.png');
  // imgAlienBasico = loadImage('assets/alien_basico.png');
}

function setup() {
  createCanvas(larguraCanvas, alturaCanvas);
  jogador = new Personagem(larguraCanvas / 2, alturaCanvas - 50);
  criarOnda();
}

function draw() {
  background(100, 150, 100); // Cenário verde da fazenda

  // Desenhar plantações e animais (apenas representação por enquanto)
  fill(0, 200, 0);
  rect(50, 50, 100, 100); // Plantação 1
  rect(larguraCanvas - 150, 50, 100, 100); // Plantação 2
  fill(200, 200, 0);
  ellipse(larguraCanvas / 2, 100, 50, 30); // Animais

  // Desenhar jogador
  jogador.desenhar();
  jogador.atualizar();

  // Desenhar e atualizar projéteis do jogador
  for (let i = projeteisJogador.length - 1; i >= 0; i--) {
    projeteisJogador[i].desenhar();
    projeteisJogador[i].atualizar();
    if (projeteisJogador[i].remover) {
      projeteisJogador.splice(i, 1);
    } else {
      projeteisJogador[i].verificarColisao(alienigenas);
    }
  }

  // Desenhar e atualizar defesas
  for (let defesa of defesas) {
    defesa.desenhar();
    defesa.atacar(alienigenas);
  }

  // Desenhar e atualizar alienígenas
  for (let i = alienigenas.length - 1; i >= 0; i--) {
    alienigenas[i].desenhar();
    alienigenas[i].atualizar();
    if (alienigenas[i].atingiuObjetivo()) {
      if (random() > 0.5) {
        vidaPlantações -= 10;
      } else {
        vidaAnimais -= 10;
      }
      alienigenas.splice(i, 1);
    }
    if (alienigenas[i].estaMorto()) {
      recursos += alienigenas[i].recompensa;
      alienigenas.splice(i, 1);
    }
  }

  // Interface do usuário
  fill(255);
  textSize(16);
  text(`Recursos: ${recursos}`, 20, 20);
  text(`Onda: ${ondaAtual}`, 20, 40);
  text(`Vida Plantações: ${vidaPlantações}`, larguraCanvas - 180, 20);
  text(`Vida Animais: ${vidaAnimais}`, larguraCanvas - 180, 40);

  // Game Over
  if (vidaPlantações <= 0 || vidaAnimais <= 0) {
    gameOver = true;
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("GAME OVER!", larguraCanvas / 2, alturaCanvas / 2);
    noLoop();
  }

  // Próxima onda
  if (alienigenas.length === 0 && !gameOver) {
    ondaAtual++;
    criarOnda();
  }
}

function mousePressed() {
  // Lógica para construir defesas (exemplo: clique para construir um trator)
  if (mouseY > 150 && recursos >= 50) {
    defesas.push(new Defesa(mouseX, mouseY, "trator"));
    recursos -= 50;
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    jogador.vx = -5;
  } else if (keyCode === RIGHT_ARROW) {
    jogador.vx = 5;
  } else if (key === ' ') {
    jogador.atirar(alienigenas);
  }
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {
    jogador.vx = 0;
  }
}

function criarOnda() {
  let numAlienigenas = ondaAtual * 3;
  for (let i = 0; i < numAlienigenas; i++) {
    let lado = floor(random(4));
    let x, y;
    if (lado === 0) { // Topo
      x = random(larguraCanvas);
      y = -20;
    } else if (lado === 1) { // Direita
      x = larguraCanvas + 20;
      y = random(alturaCanvas);
    } else if (lado === 2) { // Bottom
      x = random(larguraCanvas);
      y = alturaCanvas + 20;
    } else { // Esquerda
      x = -20;
      y = random(alturaCanvas);
    }
    alienigenas.push(new Alien(x, y));
  }
}

// Classes
class Personagem {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.largura = 30;
    this.altura = 40;
    this.vx = 0;
    this.vy = 0;
    this.velocidade = 3;
    this.cooldownTiro = 20;
    this.tempoUltimoTiro = 0;
  }

  desenhar() {
    fill(200, 100, 0);
    rect(this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
    // image(imgJogador, this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
  }

  atualizar() {
    this.x += this.vx;
    this.y += this.vy;

    this.x = constrain(this.x, this.largura / 2, larguraCanvas - this.largura / 2);
    this.y = constrain(this.y, this.altura / 2, alturaCanvas - this.altura / 2);
  }

  atirar(inimigos) {
    if (frameCount - this.tempoUltimoTiro > this.cooldownTiro) {
      let projetil = new Projetil(this.x, this.y - this.altura / 2);
      projetil.buscarAlvo(inimigos);
      projeteisJogador.push(projetil);
      this.tempoUltimoTiro = frameCount;
    }
  }
}

class Projetil {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.raio = 5;
    this.velocidade = 10;
    this.alvo = null;
    this.remover = false;
  }

  buscarAlvo(inimigos) {
    let menorDistancia = Infinity;
    let alvoMaisProximo = null;
    for (let inimigo of inimigos) {
      let distancia = dist(this.x, this.y, inimigo.x, inimigo.y);
      if (distancia < menorDistancia) {
        menorDistancia = distancia;
        alvoMaisProximo = inimigo;
      }
    }
    this.alvo = alvoMaisProximo;
  }

  desenhar() {
    fill(255, 255, 0);
    ellipse(this.x, this.y, this.raio * 2, this.raio * 2);
  }

  atualizar() {
    if (this.alvo) {
      let angulo = atan2(this.alvo.y - this.y, this.alvo.x - this.x);
      this.x += cos(angulo) * this.velocidade;
      this.y += sin(angulo) * this.velocidade;
    } else {
      this.y -= this.velocidade;
      if (this.y < 0) {
        this.remover = true;
      }
    }
  }

  verificarColisao(inimigos) {
    if (this.alvo) {
      if (dist(this.x, this.y, this.alvo.x, this.alvo.y) < this.alvo.raio) {
        this.alvo.vida -= 10;
        this.remover = true;
      }
    }
  }
}

class Defesa {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
    this.largura = 50;
    this.altura = 50;
    this.alcance = 100;
    this.dano = 5;
    this.taxaAtaque = 30; // Frames entre ataques
    this.tempoUltimoAtaque = 0;
  }

  desenhar() {
    fill(150);
    rect(this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
    // if (this.tipo === "trator") {
    //   image(imgTratorMetralhadora, this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
    // }
    // Desenhar alcance (debug)
    // noFill();
    // stroke(255, 0, 0, 100);
    // ellipse(this.x, this.y, this.alcance * 2);
    // noStroke();
  }

  atacar(inimigos) {
    if (frameCount - this.tempoUltimoAtaque > this.taxaAtaque) {
      let alvo = this.encontrarAlvo(inimigos);
      if (alvo) {
        alvo.vida -= this.dano;
        this.tempoUltimoAtaque = frameCount;
      }
    }
  }

  encontrarAlvo(inimigos) {
    let alvoMaisProximo = null;
    let menorDistancia = Infinity;
    for (let inimigo of inimigos) {
      let distancia = dist(this.x, this.y, inimigo.x, inimigo.y);
      if (distancia < menorDistancia && distancia < this.alcance) {
        menorDistancia = distancia;
        alvoMaisProximo = inimigo;
      }
    }
    return alvoMaisProximo;
  }
}

class Alien {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.raio = 20;
    this.velocidade = 1 + ondaAtual * 0.1;
    this.vida = 20 + ondaAtual * 5;
    this.recompensa = 10;
    this.objetivoX = random(50, larguraCanvas - 50);
    this.objetivoY = random(50, 150);
  }

  desenhar() {
    fill(0, 255, 0);
    ellipse(this.x, this.y, this.raio * 2, this.raio * 2);
    // image(imgAlienBasico, this.x - this.raio, this.y - this.raio, this.raio * 2, this.raio * 2);
    fill(255, 0, 0);
    rect(this.x - this.raio, this.y - this.raio - 10, this.vida / (20 + ondaAtual * 5) * this.raio * 2, 5);
  }

  atualizar() {
    let angulo = atan2(this.objetivoY - this.y, this.objetivoX - this.x);
    this.x += cos(angulo) * this.velocidade;
    this.y += sin(angulo) * this.velocidade;
  }

  atingiuObjetivo() {
    return dist(this.x, this.y, this.objetivoX, this.objetivoY) < 20;
  }

  estaMorto() {
    return this.vida <= 0;
  }
}